# 0004 — Separate Provider and Consumer Responsibilities

## Status

Accepted.

## Decision

Capability providers validate the capability implementation. Capability consumers use the capability to validate authored products.

## Consequences

- The guide system keeps methodology outside product repository truth.
- Planning, execution, documentation synchronization, and migration remain separate task modes.
